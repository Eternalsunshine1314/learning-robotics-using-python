Learning Robotics using Python
================================


Contact author if any queries
------------------------------
Author : Lentin Joseph
Email : qboticslabs@gmail.com
Website : http://www.qboticslabs.com
Portfolio : http://www.lentinjoseph.com
Contact No : +91 89 07 59 07 02

Facebook profile : https://www.facebook.com/lentin.joseph
Twitter : https://twitter.com/QboticsLabs
Linkedin : https://in.linkedin.com/pub/lentin-joseph/26/8a1/572




Operating System and ROS version for running the codes
-------------------------------

1) Operating System : Ubuntu 14.04.2 - 64 bit

Download link : http://releases.ubuntu.com/14.04/ubuntu-14.04.2-desktop-amd64.iso

2) Robot Operating System version :

Preferred Stable version : ROS Indigo Igloo

Installation link : http://wiki.ros.org/indigo/Installation/Ubuntu

Compatible latest version : ROS Jade Turtle

Installation link : http://wiki.ros.org/jade/Installation/Ubuntu



